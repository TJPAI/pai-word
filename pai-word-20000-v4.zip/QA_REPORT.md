# PAI Word 20,000 词库 QA 报告（v4：KU 按 synset 拆分＋例句按义项重配＋A+B 档经 LLM 语义重分类）

- 词头（lemma）：20000
- KU 总数：35659（ manifest 记 35659，一致：True）
- 场景 KU：15072（42.3%），兜底轨 20587
- 各大类场景 KU：社会公共 1984，日常生活 1602，自然生态 1396，社交情感 1223，教育学习 1011，健康医疗 954，文化娱乐 891，居住家居 891，商务经贸 810，饮食烹饪 715，数字科技 689，职场办公 657，金融理财 644，出行旅行 618，体育运动 499，购物消费 488
- 小类：共 319 个；空小类 0 个 []；<10 KU 的小类 26 个

- 分包完整性：404 包，sha256 不符 0 包；分包 KU 合计 35659
- slim 目录：20000 词，解压后 3964444 字节，b64 1366380 字节

- A 档：KU 7898，带例句 7791（98.6%），带中文译句 6652，带搭配 7604（96.3%），进场景 3868（49.0%）
- B 档：KU 9731，带例句 9540（98.0%），带中文译句 3876，带搭配 6682（68.7%），进场景 5202（53.5%）
- C 档：KU 18030，带例句 16725（92.8%），带中文译句 1923，带搭配 4932（27.4%），进场景 6002（33.3%）
- 美音 IPA（CMU + ipa-dict）：19255/20000（96.3%）；英音 IPA（ipa-dict en_UK）：18179/20000（90.9%）
- 义项对齐方式：{'none': 3279, 'cmn': 29373, 'order': 2399, 'def': 608}（cmn/def = 语义对齐，order = 按序回退，none = 无 WordNet 对应）
- 场景置信分层：{'llm': 9070, 'low': 3519, 'mid': 2263, 'high': 220}

- 模板句黑名单扫描：{'the role of \\w+ in': 1}（例句全部来自 WordNet/Tatoeba 真实语料）

## 定点抽查
- apple（rank 2519）n.「苹果；家伙」→ food.fruit；搭配：apple pie · apple tree · apple trees；例句：Apples grow on trees.
- apple（rank 2519）n.「苹果」→ nature.plants-flowers；搭配：apple pie · apple tree · apple trees；例句：She bit into the apple.
- issue（rank 265）n.「发行；问题；后果；流出；出口；争端」→ academic；搭配：health issues · abandonment issues · mental issues；例句：The issue could be settled by requiring public education for
- issue（rank 265）vi.「发行；流出；造成...结果；传下」→ public.newsmedia；搭配：health issues · abandonment issues · mental issues；例句：She found an old issue of the magazine in her dentist's wait
- issue（rank 265）vt.「使流出；放出；发行；发布；发给」→ public.newsmedia；搭配：health issues · abandonment issues · mental issues；例句：A new issue of stamps.
- driver（rank 1306）n.「驾驶员；驱动器；驱动程序」→ travel.taxi；搭配：taxi driver · good driver · bus driver；例句：Drivers should wear seat belts.
- driver（rank 1306）n.「驱动器」→ tech.software；搭配：taxi driver · good driver · bus driver；例句：Some of the drivers were laughing and yelling.
- guide（rank 1750）n.「引导者；导游；路标」→ travel.tickets-guide；搭配：tour guide · stars guide · guide dog；例句：They set out with a guide just in case they lost their way.
- guide（rank 1750）n.「指南」→ culture.books；搭配：tour guide · stars guide · guide dog；例句：I'm a tour guide in Tokyo.
- guide（rank 1750）vt.「指导；支配；管理；操纵」→ core3；搭配：tour guide · stars guide · guide dog；例句：This book is a good guide for beginners.
- guide（rank 1750）vt.「带领」→ travel.tickets-guide；搭配：tour guide · stars guide · guide dog；例句：We lead him to our chief.
- guide（rank 1750）vi.「任向导」→ travel.tickets-guide；搭配：tour guide · stars guide · guide dog；例句：Our guide misinformed us about the location of the hotel.
- fertility（rank 5783）n.「肥沃；丰饶；生产力」→ nature.farming；搭配：fertility clinic · fertility rate；例句：Pachamama is a goddess of earth and fertility revered by the
- fertility（rank 5783）n.「生育力」→ public.population；搭配：fertility clinic · fertility rate；例句：Sami worked at a fertility clinic.
- citrus（rank 9757）n.「柑橘属果树」→ food.fruit；搭配：citrus fruits · citrus fruit；例句：On the winter solstice we have a hot bath with yuzu citrus f
- voyage（rank 6473）n.「航行；航海；航程；旅行；航空」→ travel.boat；搭配：maiden voyage · voyage across；例句：I wish you a pleasant voyage.
- voyage（rank 6473）vi.「航海；航行」→ travel.boat；搭配：maiden voyage · voyage across；例句：The QE2 will sail to Southampton tomorrow.
- voyage（rank 6473）vt.「航行越过；飞过」→ travel.boat；搭配：maiden voyage · voyage across；例句：The Titanic's maiden voyage didn't go so well.
- charter（rank 3131）n.「特许状；执照；宪章」→ public.laws；搭配：无；例句：I want to charter a bus.
- charter（rank 3131）vt.「特许；发给特许执照」→ travel.booking；搭配：无；例句：The Premier subscribed his name to the charter.
- the（rank 1）art.「那」→ function；搭配：the door · the first · into the；例句：I was in the mountains.

## 随机抽样（A+B 档 LLM 分类结果，seed=777，每条人工可复核）
- comfort「安慰」→ 社交情感·情感表达（conf 0.5）
- den「兽穴；洞穴」→ 自然生态·陆地动物（conf 0）
- anthropologist「人类学家」→ 职场办公·职业（conf 0）
- laundry「洗衣店；洗好的衣服；洗涤」→ 居住家居·洗衣晾晒（conf 0.56）
- crystal「水晶；结晶」→ 日常生活·颜色形状材质（conf 0）
- tyre「轮胎」→ 出行旅行·自驾租车（conf 0.0）
- geometry「几何学」→ 教育学习·数学学习（conf 0）
- trade「用...进行交换」→ 商务经贸·进出口贸易（conf 0.29）
- altar「圣坛；祭坛」→ 社会公共·宗教信仰（conf 0）
- jumper「跳线连接器；跳接器」→ 数字科技·电脑硬件（conf 0）
- hatred「敌意；憎恨；憎恶」→ 社交情感·情绪心境（conf 0）
- towel「手巾；毛巾」→ 日常生活·洗漱护理（conf 0.3）
- cheap「便宜地」→ 购物消费·价格与砍价（conf 0.5）
- earn「赚得；博得」→ 金融理财·收入（conf 0.62）
- memory「存储器；内存；查看内存实用程序」→ 数字科技·电脑硬件（conf 0.33）
- tourism「旅游业」→ 出行旅行·景点观光（conf 0）
- camp「露营；帐篷」→ 体育运动·户外登山（conf 0.5）
- first「第一」→ 出行旅行·自驾租车（conf 0.0）
- striker「罢工者」→ 职场办公·职场人际（conf 0）
- speculation「投机交易；买空卖空」→ 金融理财·股票投资（conf 0）
- legend「传说；传奇文学；图例」→ 文化娱乐·故事传说（conf 0.67）
- boat「以船运」→ 出行旅行·轮船渡轮（conf 0.0）
- tube「管；软管；隧道」→ 居住家居·水电暖气（conf 0）
- rear「后面的；背面的；后方的」→ 日常生活·方向位置（conf 0.67）
- microscope「显微镜」→ 教育学习·科学学科（conf 0）

## v4 附记（2026-10-15）

### 本轮改动
- 流水线 v4：ECDICT 词性段内按中文 WordNet（cmn）匹配拆分到不同 synset；单元上限 A5/B4/C3；义项按 WordNet synset 序（即频率序）重排；例句候选按与本义项 en_def 的内容词重叠排序（按义项选句，不再按词选句）；删除空小类 travel.hotel-service，小类共 319 个。KU 总数 33,335（v1）→ 35,659。
- A+B 档共 17,629 个 KU 经 32 批分类员逐条语义重分类并全量校验合并（键集合严格一致、值全部合法）：判场景 9,070、判 none 8,559；相对旧自动标注：同 3,094、改判 2,754、旧场景→none 2,993、旧漏判补回 3,222。none 的回退轨与 build.py 同逻辑（function → academic → core 按 rank 分界）。
- 全库场景 KU 15,072 = 42.3%（A 49.0% / B 53.5% / C 33.3%）；release = pai-word-20000-v4，404 分包，哈希全过，无空小类。

### 金标集评估（冻结金标 300 条：A150/B100/C50，三人盲标多数裁定；口径与 v3 报告一致）
| 档 | 小类精确 v3→v4 | 大类 v3→v4 | 进场景判断 v3→v4 |
|---|---|---|---|
| A | 33.3% → 31.3% | 35.3% → 35.3% | 81.3% → 80.7% |
| B | 14.0% → 35.0% | 17.0% → 39.0% | 66.0% → 77.0% |
| C | 12.0% → 12.0% | 20.0% → 20.0% | 64.0% → 62.0% |
| 全库 | 23.3% → 29.3% | 26.7% → 34.0% | 73.3% → 76.3% |

- 解读：提升集中在 B 档（自动标注→LLM 重判）；A 档与 v3 持平（v3 的 A 已是同一单遍 LLM 方法，天花板在此）；C 档未动（仍自动标注）。v4 的 KU 经（单词＋释义/英文定义重叠）模糊匹配回金标条目，平均匹配分 0.883，285/300 ≥ 0.5。明细在 build/gold_eval_v4.json。
- 参照系：三位标注员三方完全一致率仅 66%——319 个小类的精确命中本身是苛刻指标，主要误差在小类边界而非大方向。

### 已知残余缺陷
1. driver、issue 的首 KU 仍是糊合释义（如 driver 首 KU「驾驶员；驱动器；驱动程序」→ travel.taxi）：其次义项在中文 WordNet 无对应词条，拆分桥断裂；已另拆出独立的「驱动器」KU → tech.software。guide 则拆分干净。
2. 部分 KU 中文释义与对齐的英文定义互相矛盾（金标裁定中发现 western、dig；分类员另报告 cat、cope、tom 等）——ECDICT 段与 WordNet 定义对齐噪声，未逐条清洗；分类时以中文释义（学习者所见）优先。
3. B 档例句带中文译句仅 3,876/9,540（40.6%），C 档 1,923/16,725（11.5%）——例句有英文原句但缺译句，未补译（补译须打机器翻译标记，属下一轮）。
4. 模板句黑名单残留 1 例（'the role of X in' 句式，语料原句，非生成模板，未剔除）。
5. C 档（18,030 KU）仍为关键词自动标注，金标小类精确 12%，如需提质须同法重判（约 33 批）。

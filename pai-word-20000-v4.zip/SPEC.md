# PAI Word 20,000 词库规格（v1，建库冻结版）

## 口径（用户 2026-10-15 拍板）
- 词头 = lemma；屈折形存 `forms`，不单独占词条
- 目标用户：多种（中小学生/大学生/成人并存）→ 选词保留考试标签（gk/cet4/cet6/ky/toefl/ielts/gre）权重修正，词条保留 `exam` 字段供前端筛选
- 场景：16 大类 × 20 小类 = 320 小类；场景覆盖优先，其余进兜底轨（function / academic / core1 / core3 / core6 / core13 / core20）
- 深度分档：A（rank 1–3,000）义项≤4、例句≤3；B（3,001–8,000）义项≤3、例句≤2；C（8,001–20,000）义项≤2、例句≤1

## 词条格式（对齐 pai-word learning-v3 分包结构）
词头级：`rank, w, pos, ipaUK(ECDICT 音标), ipaUS(CMUdict 转 IPA), band, exam, forms{plural/past/...}, s{ku_id: KU}`
KU 级：`sense_id, ku_id(w_00001_the_ku_s01 式), pos, m(中文释义), gloss_items, en_def(WordNet 英文定义), lexname, c(搭配, 语料共现), e(例句 "EN\nZH", 语料原句), x(用法提醒, v1 多为空), kuType=sense, kuTitle=释义, scene(小类 id 或 null), track(兜底轨或 null), scene_conf, alt_scenes, verified=auto`

身份：ku_id 含 rank 仅为兼容现格式；记录迁移以 (lemma, sense_id 语义序号) 为准，rank 为属性（SPEC 备注，吸取 v2→v3 迁移教训）。

## 数据源与许可
- ECDICT（MIT 系开源词库）：中文释义、音标、词频（COCA frq / BNC）、考试标签、屈折形
- WordNet（Princeton 许可）：英文定义、义项、lexname 语义域、英文例句
- Tatoeba（CC BY 2.0 FR / CC0 混合，逐句以源站为准）：中英对照例句（真实语料原句，禁止模板生成）
- CMUdict（BSD 风格许可）：美音音标转换

## 场景标注
义项级标注：打分 = 中文释义命中小类种子中文词 ×3 + 英文定义命中种子英文词 ×2 + 词头命中 ×3；最高分 ≥3 才归类，置信度 = (最高-次高)/最高。功能词义项（pron./prep./conj./aux./art.）入 function 轨；考试标签 + 抽象 lexname 且无场景命中入 academic 轨；其余入 core 词频轨。

## 交付物（out/）
- `catalog.json.b64`（gzip+base64 slim 目录：[rank, lemma, pos, [[ku_id, scene/track, kuType, kuTitle, pos, gloss]...]]）
- `scene-<major>-<minor>.json.b64` 场景包（按小类）、`track-<track>-NNN.json.b64` 兜底包（250 KU/包）
- `manifest.json`（词数/KU 数/场景与兜底计数/每包 sha256+bytes+rawBytes，对齐 v3 manifest 风格）
- `taxonomy.json`（16 大类 × 320 小类全表）、`words_master.jsonl`（全量主表）
- QA 报告见 build/QA_REPORT.md（构建后生成）
